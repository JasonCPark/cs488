/*
 * Module : intdemo.h
 *
 * Author : Greg Veres
 *
 * Date   : April 10, 1995
 *
 * Purpose: Header file for intdemo.c.
 *
 */
#ifndef __INTDEMO_H
#define __INTDEMO_H

/*
 * Function Prototypes
 */
void vInitGL(void);

#endif
